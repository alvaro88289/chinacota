export class Asignado {
  IdAsignado: number;
  IdCerUsoSuelo: number;
  IdNormaEOT: number;

  constructor(IdAsignado: number,IdCerUsoSuelo: number,IdNormaEOT: number) {
    this.IdAsignado = IdAsignado;
    this.IdCerUsoSuelo = IdCerUsoSuelo;
    this.IdNormaEOT = IdNormaEOT;
  }

}
