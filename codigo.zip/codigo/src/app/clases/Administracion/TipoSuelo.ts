export class TipoSuelo {
  IdTipoSuelo: number;
  Tipo: string;
  Codigo: number;

  constructor(IdTipoSuelo: number,Tipo: string,Codigo: number) {
    this.IdTipoSuelo = IdTipoSuelo;
    this.Tipo = Tipo;
    this.Codigo = Codigo;
  }

}
