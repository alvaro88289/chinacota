export class Estados {
  IdEstado: number;
  NombreEstado: string;

  constructor(IdEstado: number, NombreEstado: string) {
    this.IdEstado = IdEstado;
    this.NombreEstado = NombreEstado;
  }

}
