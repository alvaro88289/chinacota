export class Modulo {
  IdModulo: number;
  NombreModulo: string;

  constructor(IdModulo: number, NombreModulo: string) {
    this.IdModulo = IdModulo;
    this.NombreModulo = NombreModulo;
  }

}
