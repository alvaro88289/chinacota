export class Solicitud {
  IdSolicitud: number;
  NombreSolicitud: string;

  constructor(IdSolicitud: number, NombreSolicitud: string) {
    this.IdSolicitud = IdSolicitud;
    this.NombreSolicitud = NombreSolicitud;
  }
}
