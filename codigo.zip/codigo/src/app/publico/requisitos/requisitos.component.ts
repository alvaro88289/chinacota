import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requisitos',
  templateUrl: './requisitos.component.html',
  styleUrls: ['./requisitos.component.css']
})
export class RequisitosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
